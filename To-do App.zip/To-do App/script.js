const todoInput = document.querySelector('.todo-input');
const todoButton = document.querySelector('.todo-btn');
const todoList = document.querySelector('.todo-list');

// Add task function
todoButton.addEventListener('click', () => {
    const task = todoInput.value.trim();

    if (task) {
        const listItem = document.createElement('li');
        listItem.classList.add('todo-item');

        listItem.innerHTML = `
            <span>${task}</span>
            <button class="delete-btn">Delete</button>
        `;

        todoList.appendChild(listItem);

        // Clear input field
        todoInput.value = '';

        // Delete task function
        listItem.querySelector('.delete-btn').addEventListener('click', () => {
            listItem.remove();
        });
    }
});
